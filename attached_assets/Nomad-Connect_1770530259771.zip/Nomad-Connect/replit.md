# Nomad Connect

## Overview

Nomad Connect is a mobile-first social networking app for van lifers and digital nomads. It enables users to discover and match with other travelers (Tinder-style swiping), chat with matches, organize and join outdoor activities, participate in community forums, and access AI-powered travel advice. The app is built as a React Native/Expo application with an Express.js backend, using Supabase for authentication and PostgreSQL for data storage.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (Client)

- **Framework**: React Native with Expo SDK 54, using expo-router for file-based routing alongside React Navigation for the main navigation stack
- **Directory**: `client/` contains all frontend code; `app/` contains Expo Router entry points that delegate to the client navigation
- **Path aliases**: `@/` maps to `./client/`, `@shared/` maps to `./shared/`
- **State Management**: React Context API for auth (`AuthContext`), data (`DataContext`), theme (`ThemeContext`), and subscriptions (`SubscriptionContext`). TanStack React Query for server state/caching
- **Navigation Structure**: 
  - `RootStackNavigator` handles auth flow (Splash → Auth → Main) and modal screens (Chat, AI features, etc.)
  - `MainTabNavigator` has 5 tabs: Discover (swipe cards), Connections (matches), AI Advisor, Activities, Profile
- **Animations**: react-native-reanimated for gesture-driven animations, spring-based press feedback on cards/buttons
- **Theming**: Custom theme system supporting light/dark/system modes with warm sunset color palette (primary: `#E8744F`, accent: `#F4A261`). Theme persisted in AsyncStorage
- **UI Components**: Custom component library including ThemedText, ThemedView, SwipeCard, GradientButton, Icon (custom SVG icon system), ChatBackground, WheelPicker, etc.
- **Platform handling**: Platform-specific files for maps (`maps.native.ts`, `maps.web.ts`) and color scheme hooks. Web fallbacks for keyboard-aware views

### Backend (Server)

- **Framework**: Express.js with TypeScript, running on the same domain as the app
- **Directory**: `server/` contains backend code
- **Entry point**: `server/index.ts` sets up Express with CORS (supporting Replit domains and localhost)
- **Routes**: `server/routes.ts` defines all API endpoints
- **Storage**: `server/storage.ts` provides an in-memory storage layer with an `IStorage` interface (currently `MemStorage`, designed to be swapped for database-backed storage)
- **Build**: Server is bundled with esbuild for production (`server:build` script)

### Database

- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Defined in `shared/schema.ts` — shared between client and server
- **Tables**: users, password_reset_otps, ai_chat_sessions, activities, and more
- **Migrations**: Output to `./migrations/` directory
- **Schema push**: Use `npm run db:push` (drizzle-kit push) to sync schema to database
- **Validation**: drizzle-zod for generating Zod schemas from Drizzle table definitions
- **Connection**: Uses `DATABASE_URL` environment variable; also uses `pg` Pool directly in routes for some queries

### Authentication

- **Provider**: Supabase Auth (email/password)
- **Client**: Supabase JS client initialized in `client/lib/supabase.ts`
- **Server**: Supabase Admin client with service role key for server-side operations
- **Password Reset**: Custom OTP-based flow stored in database (password_reset_otps table)
- **Profile Persistence**: User profiles cached in AsyncStorage

### AI Features

- **Provider**: Groq API (LLaMA 3.1 8B Instant model)
- **Features**: AI chat advisor, photo analysis, cost estimator for van builds
- **Implementation**: Server-side API calls to Groq, streamed/returned to client

### Key Scripts

- `npm run expo:dev` — Start Expo dev server (configured for Replit proxy)
- `npm run server:dev` — Start Express dev server with tsx
- `npm run db:push` — Push Drizzle schema to PostgreSQL
- `npm run server:build` — Bundle server with esbuild
- `npm run server:prod` — Run production server
- `npm run expo:static:build` — Build static web bundle via custom script

## External Dependencies

- **Supabase**: Authentication and file storage (uploads bucket). Requires `EXPO_PUBLIC_SUPABASE_URL`, `EXPO_PUBLIC_SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`
- **PostgreSQL**: Primary database via `DATABASE_URL` environment variable
- **Groq API**: AI chat completions. Requires `GROQ_API_KEY`
- **Expo Services**: Splash screen, image picker, location, haptics, sensors (accelerometer for shake-to-SOS), file system, media library, SMS, audio
- **RevenueCat (react-native-purchases)**: In-app subscription management (free/pro/expert/lifetime tiers). Service layer in `client/services/revenuecat.ts`. Runs in demo/preview mode when API keys not set. Requires `EXPO_PUBLIC_REVENUECAT_IOS_KEY` and `EXPO_PUBLIC_REVENUECAT_ANDROID_KEY` secrets.
- **Subscription Gating**: `PremiumGate` component (`client/components/PremiumGate.tsx`) blocks free users from premium features. `SubscriptionContext` provides `isPro`, `isPremium`, `tier`, and `refreshSubscriptionStatus`. Pro tier gates: Social Radar, Compatibility scanning. Cost Estimator and Expert Marketplace are free for all users. `SubscriptionScreen` (`client/screens/SubscriptionScreen.tsx`) shows paywall with tier pricing.
- **React Native Maps**: Optional native maps integration (graceful fallback when unavailable)
- **Key npm packages**: expo-router, @tanstack/react-query, drizzle-orm, react-native-reanimated, react-native-gesture-handler, expo-image, expo-linear-gradient, react-native-keyboard-controller