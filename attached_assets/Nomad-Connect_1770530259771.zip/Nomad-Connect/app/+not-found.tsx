import { Redirect } from "expo-router";

export default function NotFoundScreen() {
  return <Redirect href="/" />;
}
