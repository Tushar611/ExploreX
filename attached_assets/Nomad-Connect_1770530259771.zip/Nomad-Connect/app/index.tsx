import React from "react";
import RootStackNavigator from "@/navigation/RootStackNavigator";

export default function Index() {
  return <RootStackNavigator />;
}
